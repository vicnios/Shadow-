SHADOW REBORN - ANDROID PROJECT

Package: com.shadow.reborn
Language: Java
Minimum Android: 6.0 (API 23)
Compile SDK: 30
Target SDK: 30

FEATURES
- Dark interface
- Create, select and delete local profiles
- Display Android device properties exposed to ordinary apps
- Local storage with SharedPreferences
- No root required

BUILD WITHOUT AIDE (CLOUD BUILD)
1. Extract this ZIP on your phone.
2. Create a repository on GitHub.
3. Upload the CONTENTS of this folder to the repository root (the .github folder must also be uploaded).
4. Open the repository's Actions tab.
5. Select "Build Shadow Reborn APK" and press "Run workflow" (or wait for the first push build).
6. When the workflow finishes successfully, open its run and download the artifact named
   "Shadow-Reborn-debug-apk".
7. Extract the artifact ZIP and install app-debug.apk on your Android phone.

BUILD LOCALLY
The project uses Android Gradle Plugin 4.1.3, Gradle 6.5, Java 11,
Android platform 30 and Build Tools 30.0.3. Run:
    gradle assembleDebug

IMPORTANT
This project manages local profile names only and displays the device properties
that Android exposes to the app. It does not alter system identifiers, change
properties inside other apps, spoof certificates, or bypass game integrity checks.
The GitHub Actions workflow builds an unsigned-for-release debug APK that is
signed with the standard debug key and can be installed for testing.
