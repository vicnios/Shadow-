package com.shadow.reborn;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Build;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.content.SharedPreferences;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Map;

public class MainActivity extends Activity {
    private static final int BG = Color.rgb(12, 12, 16);
    private static final int CARD = Color.rgb(25, 25, 33);
    private static final int ACCENT = Color.rgb(139, 92, 246);
    private static final int WHITE = Color.WHITE;
    private static final int MUTED = Color.rgb(164, 164, 180);

    private SharedPreferences prefs;
    private LinearLayout content;
    private String activeProfile;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("shadow_profiles", MODE_PRIVATE);
        activeProfile = prefs.getString("active_profile", "Default");
        if (!prefs.contains("profile_Default")) {
            prefs.edit().putString("profile_Default", "Default").apply();
        }
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        render();
    }

    private void render() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(20), dp(24), dp(20), dp(28));
        page.setBackgroundColor(BG);
        scroll.addView(page);
        content = page;

        TextView title = new TextView(this);
        title.setText("SHADOW REBORN");
        title.setTextColor(WHITE);
        title.setTextSize(25);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        page.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("DEVICE PROFILE MANAGER  •  VERSION 1.0");
        subtitle.setTextColor(ACCENT);
        subtitle.setTextSize(10);
        subtitle.setPadding(0, dp(5), 0, dp(20));
        page.addView(subtitle);

        section("ACTIVE PROFILE");
        LinearLayout active = card();
        TextView profileName = value(activeProfile, 18, WHITE, true);
        active.addView(profileName);
        TextView profileHint = value("Local configuration profile", 12, MUTED, false);
        profileHint.setPadding(0, dp(5), 0, 0);
        active.addView(profileHint);
        page.addView(active);

        Button choose = actionButton("SELECT / MANAGE PROFILES");
        choose.setOnClickListener(v -> showProfiles());
        page.addView(choose);
        Button create = actionButton("CREATE NEW PROFILE");
        create.setOnClickListener(v -> createProfile());
        page.addView(create);

        section("DEVICE INFORMATION");
        addInfo("Manufacturer", Build.MANUFACTURER);
        addInfo("Brand", Build.BRAND);
        addInfo("Model", Build.MODEL);
        addInfo("Device", Build.DEVICE);
        addInfo("Product", Build.PRODUCT);
        addInfo("Android version", Build.VERSION.RELEASE);
        addInfo("SDK level", String.valueOf(Build.VERSION.SDK_INT));
        addInfo("Build fingerprint", Build.FINGERPRINT);

        section("ABOUT");
        LinearLayout about = card();
        about.addView(value("Shadow Reborn stores named profiles locally and displays the device properties exposed by Android.", 13, MUTED, false));
        page.addView(about);
        setContentView(scroll);
    }

    private void section(String text) {
        TextView label = value(text, 11, ACCENT, true);
        label.setPadding(0, dp(22), 0, dp(10));
        content.addView(label);
    }

    private void addInfo(String label, String data) {
        LinearLayout box = card();
        TextView name = value(label, 11, MUTED, false);
        TextView val = value(data == null || data.length() == 0 ? "Unavailable" : data, 14, WHITE, false);
        val.setPadding(0, dp(5), 0, 0);
        box.addView(name);
        box.addView(val);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.bottomMargin = dp(8);
        content.addView(box, lp);
    }

    private LinearLayout card() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(15), dp(13), dp(15), dp(13));
        box.setBackground(roundRect(CARD, 14));
        return box;
    }

    private TextView value(String text, int size, int color, boolean bold) {
        TextView view = new TextView(this);
        view.setText(text);
        view.setTextSize(size);
        view.setTextColor(color);
        if (bold) view.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return view;
    }

    private Button actionButton(String text) {
        Button button = new Button(this);
        button.setText(text);
        button.setTextColor(WHITE);
        button.setTextSize(12);
        button.setAllCaps(false);
        button.setBackground(roundRect(ACCENT, 12));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(52));
        lp.topMargin = dp(10);
        button.setLayoutParams(lp);
        return button;
    }

    private GradientDrawable roundRect(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        return d;
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private ArrayList<String> getProfiles() {
        ArrayList<String> names = new ArrayList<>();
        Map<String, ?> all = prefs.getAll();
        for (String key : all.keySet()) {
            if (key.startsWith("profile_")) names.add(key.substring(8));
        }
        Collections.sort(names);
        if (!names.contains("Default")) names.add(0, "Default");
        return names;
    }

    private void showProfiles() {
        ArrayList<String> names = getProfiles();
        String[] items = names.toArray(new String[0]);
        new AlertDialog.Builder(this)
            .setTitle("Choose a profile")
            .setSingleChoiceItems(items, names.indexOf(activeProfile), (dialog, which) -> {
                activeProfile = names.get(which);
                prefs.edit().putString("active_profile", activeProfile).apply();
                dialog.dismiss();
                render();
            })
            .setNeutralButton("DELETE ACTIVE", (dialog, which) -> deleteActiveProfile())
            .setNegativeButton("CLOSE", null)
            .show();
    }

    private void createProfile() {
        EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setHint("Profile name");
        new AlertDialog.Builder(this)
            .setTitle("Create profile")
            .setView(input)
            .setPositiveButton("SAVE", (dialog, which) -> {
                String name = input.getText().toString().trim();
                if (name.length() == 0) {
                    Toast.makeText(this, "Enter a profile name", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (name.contains("/")) {
                    Toast.makeText(this, "Invalid profile name", Toast.LENGTH_SHORT).show();
                    return;
                }
                prefs.edit().putString("profile_" + name, name)
                    .putString("active_profile", name).apply();
                activeProfile = name;
                render();
                Toast.makeText(this, "Profile created", Toast.LENGTH_SHORT).show();
            })
            .setNegativeButton("CANCEL", null)
            .show();
    }

    private void deleteActiveProfile() {
        if ("Default".equals(activeProfile)) {
            Toast.makeText(this, "Default profile cannot be deleted", Toast.LENGTH_SHORT).show();
            return;
        }
        prefs.edit().remove("profile_" + activeProfile)
            .putString("active_profile", "Default").apply();
        activeProfile = "Default";
        render();
        Toast.makeText(this, "Profile deleted", Toast.LENGTH_SHORT).show();
    }
}
